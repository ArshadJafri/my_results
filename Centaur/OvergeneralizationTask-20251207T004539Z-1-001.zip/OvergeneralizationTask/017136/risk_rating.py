import pandas as pd
import os

dirs = os.listdir('./')
print dirs
allfiles = []
for i in dirs:
    if os.path.isdir(i):
        files = os.listdir(i)
        for j in files:
            if j.endswith('log'):
                allfiles.append(i+os.sep+j)

with open(allfiles[3]) as fid:
    lines = fid.readlines()
    
data = []
for i, line in enumerate(lines):
    if i == 3:
        columns = line.strip('\r\n').split('\t')
    elif line.startswith(sub_id):
        linesplit = line.strip('\r\n').split('\t')
        if linesplit:
            data.append(line.strip('\r\n').split('\t'))
        else:
            break
    
df = pd.DataFrame(data, columns = columns)
df['Time'] = df['Time'].map(int)

trial = ''
count_trials = 0
trialDataDict = {}

for i, row in df.iterrows():
    #if i == 55:
    #    break
    ####handle the first trail which starts with response
    if row['Trial'] == '1':
        continue
    
    ####split trial data into {key:value} dict: key(trial id), value
    if row['Trial'] != trial:
        count_trials += 1

        ####seems like every new trail starts with a picture with all numeric codes
        if row['Event Type'] != 'Picture' or  not row['Code'].isdigit():
            print "This trail didn't start with picture with all numeric codes %s\n" % row['Trial']
            
        if count_trials > 1:
            trialDataDict[int(trial)] = trial_data ####cast key into integer for numeric sorting
        trial = row['Trial']
        trial_data = [[row['Trial'], row['Event Type'], row['Code'], row['Time']],]
    else:
        trial_data.append([row['Trial'], row['Event Type'], row['Code'], row['Time']])
    
    ####make sure the last trial was saved to the dict properly    
    if i == len(df)-1:
        trialDataDict[int(trial)] = trial_data       
        
def get_output(trial, trialData):
    picture_data = []
    response_data = []
    ###get valid picture time
    for i, tData in enumerate(trialData):
        if i == 0:
            assert(tData[1] == 'Picture')
            assert(tData[2].isdigit())
            if tData[2].endswith('0'):
                return []
            elif tData[2].endswith('1'):
                picture_data = tData
                break
            else:
                picture_data = tData
        elif tData[2].endswith('r'):
            picture_data[-1] = tData[-1]
            break
    
    ###get valid response time
    for i, tData in enumerate(trialData[::-1]):
        if tData[1] == 'Response':
            response_data = tData
    
    if picture_data and response_data:
        return [picture_data[1], picture_data[2], response_data[2], response_data[-1]-picture_data[-1]]
    elif picture_data:
        return [picture_data[1], picture_data[2], '', -1]
    elif response_data:
        print 'Not valid since no prior picture!\n'
        return []

result = [['Event Type', 'Code', 'Response Type', 'Time'],]
for trial in sorted(trialDataDict.keys()):
    output = get_output(trial, trialDataDict[trial])
    if not output:
        continue
    result.append(output)
dfOutput = pd.DataFrame(result[1:], columns=result[0])

#with open('output.csv', 'w') as fid: 
#    dfOutput.to_csv(fid, index=False)